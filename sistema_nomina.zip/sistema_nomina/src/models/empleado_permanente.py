"""Clase abstracta intermedia para empleados permanentes.

Refactorización: el beneficio de alimentación estaba duplicado en
EmpleadoAsalariado y EmpleadoComision. Se extrajo aquí una sola vez.
"""
from .empleado import Empleado

BENEFICIO_ALIMENTACION = 1_000_000  # Mensual, cubierto por la empresa.


class EmpleadoPermanente(Empleado):
    def obtener_beneficios(self):
        return {"Alimentación": BENEFICIO_ALIMENTACION}

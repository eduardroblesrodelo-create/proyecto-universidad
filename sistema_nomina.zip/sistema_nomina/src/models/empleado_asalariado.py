from .empleado_permanente import EmpleadoPermanente
from .validaciones import validar_no_negativo


class EmpleadoAsalariado(EmpleadoPermanente):
    """Salario fijo mensual. Bono del 10 % si lleva más de 5 años."""
    TIPO = "Empleado asalariado"
    ANIOS_PARA_BONO = 5
    PORCENTAJE_BONO = 0.10

    def __init__(self, identificacion, nombre, anios_antiguedad, salario_mensual):
        super().__init__(identificacion, nombre, anios_antiguedad)
        self._salario_mensual = validar_no_negativo(salario_mensual, "Salario mensual")

    def calcular_salario_base(self):
        return self._salario_mensual

    def obtener_bonos(self):
        if self.anios_antiguedad > self.ANIOS_PARA_BONO:
            return {"Bono por antigüedad (10 %)": self._salario_mensual * self.PORCENTAJE_BONO}
        return {}

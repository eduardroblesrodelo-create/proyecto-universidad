from .empleado import Empleado
from .validaciones import validar_entero_positivo, validar_no_negativo


class EmpleadoTemporal(Empleado):
    """Salario fijo mensual con contrato por tiempo definido.

    No recibe bonos ni beneficios: usa los valores por defecto de Empleado.
    """
    TIPO = "Empleado temporal"

    def __init__(self, identificacion, nombre, anios_antiguedad,
                 salario_mensual, duracion_contrato_meses):
        super().__init__(identificacion, nombre, anios_antiguedad)
        self._salario_mensual = validar_no_negativo(salario_mensual, "Salario mensual")
        self._duracion_contrato_meses = validar_entero_positivo(
            duracion_contrato_meses, "Duración del contrato (meses)")

    @property
    def duracion_contrato_meses(self):
        return self._duracion_contrato_meses

    def calcular_salario_base(self):
        return self._salario_mensual

"""Clase base abstracta Empleado.

Contiene solo lo común a todos los tipos de empleado. Cada subclase define
su propia forma de calcular el salario base, sus bonos y sus beneficios
(polimorfismo). El cálculo del salario bruto vive aquí una sola vez
(patrón "método plantilla"), así no se repite en cada subclase.
"""
from abc import ABC, abstractmethod

from .validaciones import validar_no_negativo, validar_texto_obligatorio


class Empleado(ABC):
    TIPO = "Empleado"  # Cada subclase lo sobrescribe con su nombre visible.

    def __init__(self, identificacion, nombre, anios_antiguedad):
        # Atributos "privados" (encapsulamiento): se leen por propiedades.
        self._identificacion = validar_texto_obligatorio(identificacion, "Identificación")
        self._nombre = validar_texto_obligatorio(nombre, "Nombre")
        self._anios_antiguedad = validar_no_negativo(anios_antiguedad, "Antigüedad (años)")

    @property
    def identificacion(self):
        return self._identificacion

    @property
    def nombre(self):
        return self._nombre

    @property
    def anios_antiguedad(self):
        return self._anios_antiguedad

    @property
    def tipo(self):
        return self.TIPO

    @abstractmethod
    def calcular_salario_base(self):
        """Pago principal del empleado, sin bonos. Lo define cada subclase."""

    def obtener_bonos(self):
        """Bonos como {descripción: valor}. Por defecto no hay bonos."""
        return {}

    def obtener_beneficios(self):
        """Beneficios cubiertos por la empresa como {descripción: valor}."""
        return {}

    def calcular_salario_bruto(self):
        """Salario bruto = salario base + bonos."""
        return self.calcular_salario_base() + sum(self.obtener_bonos().values())

    def calcular_salario_neto(self, deducciones):
        """Salario neto = salario bruto - deducciones (nunca negativo)."""
        salario_neto = self.calcular_salario_bruto() - deducciones
        if salario_neto < 0:
            raise ValueError("El salario neto no puede ser negativo.")
        return salario_neto

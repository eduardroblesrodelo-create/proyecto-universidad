from .empleado import Empleado
from .validaciones import validar_no_negativo


class EmpleadoPorHoras(Empleado):
    """Paga por hora. Después de 40 horas, cada hora se paga x1.5.

    No recibe bonos. Con más de 1 año de antigüedad puede participar
    (si lo acepta) en un fondo de ahorro del 2 % de su salario.
    """
    TIPO = "Empleado por horas"
    HORAS_NORMALES_MAXIMAS = 40
    FACTOR_HORA_EXTRA = 1.5
    ANIOS_PARA_FONDO_AHORRO = 1
    PORCENTAJE_FONDO_AHORRO = 0.02

    def __init__(self, identificacion, nombre, anios_antiguedad,
                 tarifa_hora, horas_trabajadas, acepta_fondo_ahorro=False):
        super().__init__(identificacion, nombre, anios_antiguedad)
        self._tarifa_hora = validar_no_negativo(tarifa_hora, "Tarifa por hora")
        self._horas_trabajadas = validar_no_negativo(horas_trabajadas, "Horas trabajadas")
        self._acepta_fondo_ahorro = bool(acepta_fondo_ahorro)

    @property
    def horas_normales(self):
        return min(self._horas_trabajadas, self.HORAS_NORMALES_MAXIMAS)

    @property
    def horas_extras(self):
        return max(self._horas_trabajadas - self.HORAS_NORMALES_MAXIMAS, 0)

    def calcular_salario_base(self):
        pago_normal = self.horas_normales * self._tarifa_hora
        pago_extra = self.horas_extras * self._tarifa_hora * self.FACTOR_HORA_EXTRA
        return pago_normal + pago_extra

    def puede_acceder_fondo_ahorro(self):
        return self.anios_antiguedad > self.ANIOS_PARA_FONDO_AHORRO

    def obtener_beneficios(self):
        if self.puede_acceder_fondo_ahorro() and self._acepta_fondo_ahorro:
            aporte = self.calcular_salario_base() * self.PORCENTAJE_FONDO_AHORRO
            return {"Fondo de ahorro (2 %)": aporte}
        return {}

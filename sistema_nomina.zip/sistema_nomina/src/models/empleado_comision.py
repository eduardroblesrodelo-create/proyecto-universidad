from .empleado_permanente import EmpleadoPermanente
from .validaciones import validar_no_negativo, validar_porcentaje


class EmpleadoComision(EmpleadoPermanente):
    """Salario base + comisión sobre ventas.

    Si las ventas superan $20.000.000 recibe un bono del 3 % de las ventas.
    """
    TIPO = "Empleado por comisión"
    VENTAS_PARA_BONO = 20_000_000
    PORCENTAJE_BONO = 0.03

    def __init__(self, identificacion, nombre, anios_antiguedad,
                 salario_base, porcentaje_comision, ventas):
        super().__init__(identificacion, nombre, anios_antiguedad)
        self._salario_base = validar_no_negativo(salario_base, "Salario base")
        # El porcentaje es una fracción: 0.05 equivale a 5 %.
        self._porcentaje_comision = validar_porcentaje(porcentaje_comision, "Porcentaje de comisión")
        self._ventas = validar_no_negativo(ventas, "Ventas")

    def calcular_comision(self):
        return self._ventas * self._porcentaje_comision

    def calcular_salario_base(self):
        return self._salario_base + self.calcular_comision()

    def obtener_bonos(self):
        if self._ventas > self.VENTAS_PARA_BONO:
            return {"Bono por ventas (3 %)": self._ventas * self.PORCENTAJE_BONO}
        return {}

from .empleado import Empleado
from .empleado_asalariado import EmpleadoAsalariado
from .empleado_comision import EmpleadoComision
from .empleado_por_horas import EmpleadoPorHoras
from .empleado_temporal import EmpleadoTemporal

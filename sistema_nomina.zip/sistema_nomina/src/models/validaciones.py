"""Validaciones reutilizables para los datos de los empleados.

Refactorización: estas reglas estaban repetidas en cada clase de empleado;
ahora viven en un solo lugar (principio DRY y responsabilidad única).
"""
import math


def _validar_numero(valor, nombre):
    """Confirma que el valor sea un número real (no texto, no bool, no NaN/inf)."""
    es_numero = isinstance(valor, (int, float)) and not isinstance(valor, bool)
    if not es_numero or not math.isfinite(valor):
        raise ValueError(f"{nombre}: debe ser un número válido.")


def validar_no_negativo(valor, nombre):
    """Rechaza valores menores que cero (salarios, tarifas, horas, ventas...)."""
    _validar_numero(valor, nombre)
    if valor < 0:
        raise ValueError(f"{nombre}: el valor no puede ser menor que cero.")
    return valor


def validar_porcentaje(valor, nombre):
    """El porcentaje se maneja como fracción: 0.05 equivale a 5 %."""
    _validar_numero(valor, nombre)
    if not 0 <= valor <= 1:
        raise ValueError(f"{nombre}: el porcentaje debe estar entre 0 % y 100 %.")
    return valor


def validar_entero_positivo(valor, nombre):
    """Para datos como la duración del contrato en meses."""
    _validar_numero(valor, nombre)
    if valor <= 0 or int(valor) != valor:
        raise ValueError(f"{nombre}: debe ser un número entero mayor que cero.")
    return int(valor)


def validar_texto_obligatorio(valor, nombre):
    """Evita identificaciones o nombres vacíos."""
    if not isinstance(valor, str) or not valor.strip():
        raise ValueError(f"{nombre}: este campo es obligatorio.")
    return valor.strip()

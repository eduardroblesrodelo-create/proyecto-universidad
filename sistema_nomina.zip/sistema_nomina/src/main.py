"""Punto de entrada. Ejecutar desde la raíz del proyecto: python -m src.main"""
from src.ui.ventana_nomina import VentanaNomina


def main():
    VentanaNomina().mainloop()


if __name__ == "__main__":
    main()

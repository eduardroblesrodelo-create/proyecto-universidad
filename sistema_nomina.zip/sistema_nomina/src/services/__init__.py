from .nomina_service import NominaService, ResultadoNomina

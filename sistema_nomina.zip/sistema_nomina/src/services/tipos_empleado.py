"""Registro de los tipos de empleado disponibles y sus campos de entrada.

OCP: para agregar un nuevo tipo basta con crear su clase y añadir una línea
a TIPOS_EMPLEADO. Ni el menú ni el servicio de nómina se modifican.
La clave de cada campo coincide con el nombre del parámetro del constructor.
"""
from dataclasses import dataclass

from src.models import (EmpleadoAsalariado, EmpleadoComision,
                        EmpleadoPorHoras, EmpleadoTemporal)
from .convertidores import CONVERTIDORES


@dataclass(frozen=True)
class Campo:
    clave: str
    etiqueta: str
    tipo: str  # texto | numero | entero | porcentaje | si_no


@dataclass(frozen=True)
class TipoEmpleado:
    clase: type
    campos_especificos: tuple

    @property
    def nombre(self):
        return self.clase.TIPO

    @property
    def campos(self):
        return CAMPOS_COMUNES + self.campos_especificos


CAMPOS_COMUNES = (
    Campo("identificacion", "Identificación", "texto"),
    Campo("nombre", "Nombre", "texto"),
    Campo("anios_antiguedad", "Antigüedad (años)", "numero"),
)

TIPOS_EMPLEADO = (
    TipoEmpleado(EmpleadoAsalariado, (
        Campo("salario_mensual", "Salario mensual ($)", "numero"),
    )),
    TipoEmpleado(EmpleadoPorHoras, (
        Campo("tarifa_hora", "Tarifa por hora ($)", "numero"),
        Campo("horas_trabajadas", "Horas trabajadas", "numero"),
        Campo("acepta_fondo_ahorro", "¿Acepta fondo de ahorro?", "si_no"),
    )),
    TipoEmpleado(EmpleadoComision, (
        Campo("salario_base", "Salario base ($)", "numero"),
        Campo("porcentaje_comision", "Comisión sobre ventas (%)", "porcentaje"),
        Campo("ventas", "Ventas ($)", "numero"),
    )),
    TipoEmpleado(EmpleadoTemporal, (
        Campo("salario_mensual", "Salario mensual ($)", "numero"),
        Campo("duracion_contrato_meses", "Duración del contrato (meses)", "entero"),
    )),
)


def obtener_tipo(nombre):
    for tipo in TIPOS_EMPLEADO:
        if tipo.nombre == nombre:
            return tipo
    raise ValueError(f"Tipo de empleado desconocido: {nombre}")


def crear_empleado(tipo, textos):
    """Convierte los textos del formulario y construye el empleado.

    Lanza ValueError con un mensaje claro si algún dato es inválido.
    """
    valores = {
        campo.clave: CONVERTIDORES[campo.tipo](textos.get(campo.clave, ""), campo.etiqueta)
        for campo in tipo.campos
    }
    return tipo.clase(**valores)

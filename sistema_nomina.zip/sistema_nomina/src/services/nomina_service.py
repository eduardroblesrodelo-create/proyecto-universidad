"""Servicio de nómina: calcula el resultado final de cualquier empleado.

Depende de la abstracción Empleado (no de las clases concretas), por lo que
funciona con cualquier tipo nuevo sin modificarse (OCP, LSP y DIP).

ARL: la actividad no define un porcentaje; debe ser definido por el docente.
Por eso NO se calcula ni se inventa ningún valor.
"""
from dataclasses import dataclass, field

from src.models.empleado import Empleado
from src.models.validaciones import validar_porcentaje

PORCENTAJE_SEGURO_SOCIAL_PENSION = 0.04


@dataclass(frozen=True)
class ResultadoNomina:
    """Datos finales de la nómina de un empleado."""
    nombre: str
    tipo: str
    salario_bruto: float
    deducciones: float
    salario_neto: float
    bonos: dict = field(default_factory=dict)
    beneficios: dict = field(default_factory=dict)


class NominaService:
    def __init__(self, porcentaje_deduccion=PORCENTAJE_SEGURO_SOCIAL_PENSION):
        self._porcentaje_deduccion = validar_porcentaje(
            porcentaje_deduccion, "Porcentaje de deducción")

    def calcular_deducciones(self, salario_bruto):
        """Seguro Social y Pensión = 4 % del salario bruto."""
        return salario_bruto * self._porcentaje_deduccion

    def calcular_nomina(self, empleado: Empleado) -> ResultadoNomina:
        # Polimorfismo: el servicio no sabe qué tipo de empleado recibe.
        salario_bruto = empleado.calcular_salario_bruto()
        deducciones = self.calcular_deducciones(salario_bruto)
        return ResultadoNomina(
            nombre=empleado.nombre,
            tipo=empleado.tipo,
            salario_bruto=salario_bruto,
            deducciones=deducciones,
            salario_neto=empleado.calcular_salario_neto(deducciones),
            bonos=empleado.obtener_bonos(),
            beneficios=empleado.obtener_beneficios(),
        )

"""Convierte los textos escritos por el usuario en valores numéricos o booleanos.

Formato aceptado: puntos para miles y coma para decimales (3.000.000 o 40,5).
"""
import re

_MILES_COLOMBIANOS = re.compile(r"\d{1,3}(\.\d{3})+(,\d+)?")


def convertir_texto(texto, etiqueta):
    return texto.strip()


def convertir_numero(texto, etiqueta):
    limpio = texto.strip().replace("$", "").replace(" ", "")
    if not limpio:
        raise ValueError(f"{etiqueta}: este campo es obligatorio.")
    if _MILES_COLOMBIANOS.fullmatch(limpio):
        limpio = limpio.replace(".", "").replace(",", ".")
    else:
        limpio = limpio.replace(",", ".")
    try:
        return float(limpio)
    except ValueError:
        raise ValueError(f"{etiqueta}: '{texto}' no es un número válido.") from None


def convertir_entero(texto, etiqueta):
    numero = convertir_numero(texto, etiqueta)
    if not numero.is_integer():
        raise ValueError(f"{etiqueta}: debe ser un número entero.")
    return int(numero)


def convertir_porcentaje(texto, etiqueta):
    """El usuario escribe 5 (por 5 %); el modelo recibe 0.05."""
    return convertir_numero(texto, etiqueta) / 100


def convertir_si_no(texto, etiqueta):
    valor = texto.strip().lower()
    if valor in ("sí", "si", "s"):
        return True
    if valor in ("no", "n", ""):
        return False
    raise ValueError(f"{etiqueta}: responda Sí o No.")


CONVERTIDORES = {
    "texto": convertir_texto,
    "numero": convertir_numero,
    "entero": convertir_entero,
    "porcentaje": convertir_porcentaje,
    "si_no": convertir_si_no,
}

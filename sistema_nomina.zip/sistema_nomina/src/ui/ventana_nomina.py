"""Interfaz gráfica (Tkinter). Solo muestra datos y atrapa errores:
toda la lógica de negocio está en models/ y services/."""
import tkinter as tk
from tkinter import ttk

from src.services.nomina_service import NominaService
from src.services.tipos_empleado import TIPOS_EMPLEADO, crear_empleado, obtener_tipo

COLOR_ERROR = "#b00020"
COLOR_TITULO = "#1f3a5f"


def formatear_pesos(valor):
    """3000000 -> $3.000.000 ; 19000.5 -> $19.000,50"""
    texto = f"{valor:,.0f}" if float(valor).is_integer() else f"{valor:,.2f}"
    return "$" + texto.replace(",", "_").replace(".", ",").replace("_", ".")


class VentanaNomina(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Sistema de Nómina")
        self.minsize(860, 540)
        self._servicio = NominaService()
        self._variables = {}
        self._tipo_var = tk.StringVar(value=TIPOS_EMPLEADO[0].nombre)
        self._construir_interfaz()
        self._mostrar_campos()

    # ---------- construcción de la ventana ----------
    def _construir_interfaz(self):
        ttk.Style(self).theme_use("clam")
        ttk.Label(self, text="Sistema de Nómina", font=("Segoe UI", 18, "bold"),
                  foreground=COLOR_TITULO).pack(pady=(14, 6))

        cuerpo = ttk.Frame(self, padding=10)
        cuerpo.pack(fill="both", expand=True)
        cuerpo.columnconfigure(0, weight=1)
        cuerpo.columnconfigure(1, weight=1)

        formulario = ttk.LabelFrame(cuerpo, text="Datos del empleado", padding=12)
        formulario.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        self._construir_formulario(formulario)

        self._panel_resultado = ttk.LabelFrame(cuerpo, text="Resultado de la nómina", padding=12)
        self._panel_resultado.grid(row=0, column=1, sticky="nsew", padx=(6, 0))

        ttk.Label(self, text=("Universidad de Cartagena · Centro Tutorial Mompox · "
                              "CIPA: Compiladores del Futuro\n"
                              "Deducción: Seguro Social y Pensión 4 %. "
                              "ARL: porcentaje por definir por el docente (no incluido)."),
                  justify="center", foreground="#555555").pack(pady=8)

    def _construir_formulario(self, contenedor):
        ttk.Label(contenedor, text="Tipo de empleado").grid(row=0, column=0, sticky="w", pady=4)
        selector = ttk.Combobox(contenedor, textvariable=self._tipo_var, state="readonly", width=28,
                                values=[tipo.nombre for tipo in TIPOS_EMPLEADO])
        selector.grid(row=0, column=1, sticky="ew", pady=4)
        selector.bind("<<ComboboxSelected>>", lambda _: self._mostrar_campos())

        self._marco_campos = ttk.Frame(contenedor)
        self._marco_campos.grid(row=1, column=0, columnspan=2, sticky="ew")
        contenedor.columnconfigure(1, weight=1)

        self._etiqueta_error = ttk.Label(contenedor, foreground=COLOR_ERROR, wraplength=330)
        self._etiqueta_error.grid(row=2, column=0, columnspan=2, sticky="w", pady=6)

        botones = ttk.Frame(contenedor)
        botones.grid(row=3, column=0, columnspan=2, pady=4)
        ttk.Button(botones, text="Calcular nómina", command=self._calcular).pack(side="left", padx=4)
        ttk.Button(botones, text="Limpiar", command=self._mostrar_campos).pack(side="left", padx=4)

    # ---------- formulario dinámico (generado desde el registro de tipos) ----------
    def _mostrar_campos(self):
        for widget in self._marco_campos.winfo_children():
            widget.destroy()
        self._variables = {}
        self._etiqueta_error.config(text="")
        self._limpiar_resultado()

        tipo = obtener_tipo(self._tipo_var.get())
        self._marco_campos.columnconfigure(1, weight=1)
        for fila, campo in enumerate(tipo.campos):
            variable = tk.StringVar(value="No" if campo.tipo == "si_no" else "")
            self._variables[campo.clave] = variable
            ttk.Label(self._marco_campos, text=campo.etiqueta).grid(row=fila, column=0, sticky="w", pady=4)
            if campo.tipo == "si_no":
                entrada = ttk.Combobox(self._marco_campos, textvariable=variable,
                                       values=["No", "Sí"], state="readonly", width=28)
            else:
                entrada = ttk.Entry(self._marco_campos, textvariable=variable, width=30)
            entrada.grid(row=fila, column=1, sticky="ew", pady=4, padx=(8, 0))

    # ---------- acciones ----------
    def _calcular(self):
        self._etiqueta_error.config(text="")
        textos = {clave: variable.get() for clave, variable in self._variables.items()}
        try:
            empleado = crear_empleado(obtener_tipo(self._tipo_var.get()), textos)
            resultado = self._servicio.calcular_nomina(empleado)
        except ValueError as error:
            self._limpiar_resultado()
            self._etiqueta_error.config(text=f"⚠ {error}")
            return
        self._mostrar_resultado(resultado)

    def _limpiar_resultado(self):
        for widget in self._panel_resultado.winfo_children():
            widget.destroy()

    def _mostrar_resultado(self, resultado):
        self._limpiar_resultado()
        filas = [("Nombre", resultado.nombre, False),
                 ("Tipo de empleado", resultado.tipo, False),
                 ("Salario bruto", formatear_pesos(resultado.salario_bruto), False)]
        if resultado.bonos:
            filas.append(("Bonos", "", True))
            filas += [(f"   {nombre}", formatear_pesos(valor), False)
                      for nombre, valor in resultado.bonos.items()]
        if resultado.beneficios:
            filas.append(("Beneficios", "", True))
            filas += [(f"   {nombre}", formatear_pesos(valor), False)
                      for nombre, valor in resultado.beneficios.items()]
        filas.append(("Deducciones (Seguro Social y Pensión 4 %)",
                      "-" + formatear_pesos(resultado.deducciones), False))
        filas.append(("SALARIO NETO", formatear_pesos(resultado.salario_neto), True))

        self._panel_resultado.columnconfigure(1, weight=1)
        for numero, (etiqueta, valor, negrita) in enumerate(filas):
            fuente = ("Segoe UI", 10, "bold") if negrita else ("Segoe UI", 10)
            ttk.Label(self._panel_resultado, text=etiqueta, font=fuente).grid(
                row=numero, column=0, sticky="w", pady=3)
            ttk.Label(self._panel_resultado, text=valor, font=fuente).grid(
                row=numero, column=1, sticky="e", pady=3, padx=(12, 0))

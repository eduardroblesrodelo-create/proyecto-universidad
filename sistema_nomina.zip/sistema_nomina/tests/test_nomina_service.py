import pytest
from src.models import (Empleado, EmpleadoAsalariado, EmpleadoComision,
                        EmpleadoPorHoras, EmpleadoTemporal)
from src.services import NominaService


def test_deduccion_del_4_por_ciento():
    assert NominaService().calcular_deducciones(3_000_000) == pytest.approx(120_000)


def test_salario_neto_asalariado_con_bono():
    resultado = NominaService().calcular_nomina(
        EmpleadoAsalariado("1", "Ana", 6, 3_000_000))
    assert resultado.salario_bruto == pytest.approx(3_300_000)
    assert resultado.deducciones == pytest.approx(132_000)
    assert resultado.salario_neto == pytest.approx(3_168_000)


def test_salario_neto_comision():
    resultado = NominaService().calcular_nomina(
        EmpleadoComision("3", "Marta", 2, 2_000_000, 0.05, 25_000_000))
    assert resultado.salario_neto == pytest.approx(3_840_000)


def test_polimorfismo_funciona_con_todos_los_tipos_y_neto_nunca_negativo():
    empleados = [
        EmpleadoAsalariado("1", "A", 6, 3_000_000),
        EmpleadoPorHoras("2", "B", 2, 20_000, 45, True),
        EmpleadoComision("3", "C", 2, 2_000_000, 0.05, 25_000_000),
        EmpleadoTemporal("4", "D", 0, 2_500_000, 6),
    ]
    servicio = NominaService()
    for empleado in empleados:  # LSP: todos se tratan como Empleado
        resultado = servicio.calcular_nomina(empleado)
        assert resultado.salario_neto >= 0
        assert resultado.salario_neto == pytest.approx(resultado.salario_bruto - resultado.deducciones)


def test_rechaza_salario_neto_negativo():
    with pytest.raises(ValueError):
        EmpleadoAsalariado("1", "Ana", 0, 1_000_000).calcular_salario_neto(2_000_000)


def test_servicio_rechaza_salario_neto_negativo_de_un_empleado_defectuoso():
    class EmpleadoDefectuoso(Empleado):
        def calcular_salario_base(self):
            return -100

    with pytest.raises(ValueError):
        NominaService().calcular_nomina(EmpleadoDefectuoso("9", "X", 0))


def test_ocp_nuevo_tipo_funciona_sin_modificar_el_servicio():
    class EmpleadoPracticante(Empleado):
        TIPO = "Practicante"

        def calcular_salario_base(self):
            return 1_000_000

    resultado = NominaService().calcular_nomina(EmpleadoPracticante("5", "Eva", 0))
    assert resultado.tipo == "Practicante"
    assert resultado.salario_neto == pytest.approx(960_000)

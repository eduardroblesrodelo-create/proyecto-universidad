import pytest
from src.models import EmpleadoComision


def crear(ventas=25_000_000, porcentaje=0.05):
    return EmpleadoComision("3", "Marta", 2, 2_000_000, porcentaje, ventas)


def test_calculo_de_comision():
    assert crear().calcular_comision() == pytest.approx(1_250_000)


def test_bono_3_por_ciento_si_ventas_superan_20_millones():
    empleado = crear(ventas=25_000_000)
    assert empleado.obtener_bonos() == {"Bono por ventas (3 %)": pytest.approx(750_000)}
    # 2.000.000 + 1.250.000 + 750.000
    assert empleado.calcular_salario_bruto() == pytest.approx(4_000_000)


def test_sin_bono_si_ventas_no_superan_20_millones():
    assert crear(ventas=20_000_000).obtener_bonos() == {}


def test_recibe_beneficio_de_alimentacion():
    assert crear().obtener_beneficios() == {"Alimentación": 1_000_000}


def test_rechaza_ventas_negativas():
    with pytest.raises(ValueError):
        crear(ventas=-1)


@pytest.mark.parametrize("porcentaje", [-0.1, 1.5])
def test_rechaza_porcentaje_invalido(porcentaje):
    with pytest.raises(ValueError):
        crear(porcentaje=porcentaje)

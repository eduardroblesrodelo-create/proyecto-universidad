import pytest
from src.models import EmpleadoAsalariado


def crear(anios=3, salario=3_000_000):
    return EmpleadoAsalariado("1", "Ana", anios, salario)


def test_salario_fijo():
    assert crear().calcular_salario_base() == 3_000_000


def test_bono_10_por_ciento_con_mas_de_5_anios():
    empleado = crear(anios=6)
    assert empleado.obtener_bonos() == {"Bono por antigüedad (10 %)": pytest.approx(300_000)}
    assert empleado.calcular_salario_bruto() == pytest.approx(3_300_000)


def test_sin_bono_con_5_anios_o_menos():
    assert crear(anios=5).obtener_bonos() == {}
    assert crear(anios=2).calcular_salario_bruto() == 3_000_000


def test_recibe_beneficio_de_alimentacion():
    assert crear().obtener_beneficios() == {"Alimentación": 1_000_000}


def test_rechaza_salario_negativo():
    with pytest.raises(ValueError):
        crear(salario=-1)

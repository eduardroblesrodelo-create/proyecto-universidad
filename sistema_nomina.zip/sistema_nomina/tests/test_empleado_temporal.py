import pytest
from src.models import EmpleadoTemporal


def crear(meses=6):
    return EmpleadoTemporal("4", "Pedro", 0, 2_500_000, meses)


def test_salario_fijo():
    assert crear().calcular_salario_bruto() == 2_500_000


def test_no_recibe_bonos_ni_beneficios():
    empleado = crear()
    assert empleado.obtener_bonos() == {}
    assert empleado.obtener_beneficios() == {}


@pytest.mark.parametrize("meses", [0, -3, 2.5])
def test_contrato_debe_tener_duracion_entera_positiva(meses):
    with pytest.raises(ValueError):
        crear(meses=meses)

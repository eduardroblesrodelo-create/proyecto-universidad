"""Pruebas de la conversión de datos escritos por el usuario (formulario)."""
import pytest
from src.services.tipos_empleado import TIPOS_EMPLEADO, crear_empleado, obtener_tipo

BASE = {"identificacion": "1", "nombre": "Ana", "anios_antiguedad": "6"}


def test_acepta_formato_colombiano_y_crea_el_empleado():
    datos = {**BASE, "salario_mensual": "3.000.000"}
    empleado = crear_empleado(obtener_tipo("Empleado asalariado"), datos)
    assert empleado.calcular_salario_bruto() == pytest.approx(3_300_000)


def test_porcentaje_se_escribe_como_5_y_se_convierte_a_fraccion():
    datos = {**BASE, "salario_base": "2.000.000", "porcentaje_comision": "5",
             "ventas": "25.000.000"}
    empleado = crear_empleado(obtener_tipo("Empleado por comisión"), datos)
    assert empleado.calcular_comision() == pytest.approx(1_250_000)


@pytest.mark.parametrize("valor", ["abc", "", "-5"])
def test_datos_invalidos_generan_mensaje_claro(valor):
    datos = {**BASE, "tarifa_hora": valor, "horas_trabajadas": "10",
             "acepta_fondo_ahorro": "No"}
    with pytest.raises(ValueError, match="Tarifa por hora"):
        crear_empleado(obtener_tipo("Empleado por horas"), datos)


def test_hay_cuatro_tipos_registrados():
    assert len(TIPOS_EMPLEADO) == 4

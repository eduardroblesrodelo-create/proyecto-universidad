import pytest
from src.models import EmpleadoPorHoras


def crear(horas=45, anios=2, acepta=True, tarifa=20_000):
    return EmpleadoPorHoras("2", "Luis", anios, tarifa, horas, acepta)


def test_horas_normales_sin_extras():
    empleado = crear(horas=30)
    assert empleado.horas_normales == 30 and empleado.horas_extras == 0
    assert empleado.calcular_salario_base() == 600_000


def test_horas_extras_despues_de_40_se_pagan_x1_5():
    empleado = crear(horas=45)
    assert empleado.horas_normales == 40 and empleado.horas_extras == 5
    # 40 * 20.000 + 5 * 30.000
    assert empleado.calcular_salario_base() == pytest.approx(950_000)


def test_no_recibe_bonos():
    assert crear().obtener_bonos() == {}


def test_rechaza_horas_negativas():
    with pytest.raises(ValueError):
        crear(horas=-1)


def test_fondo_de_ahorro_2_por_ciento_si_acepta_y_supera_1_anio():
    beneficios = crear(horas=45, anios=2, acepta=True).obtener_beneficios()
    assert beneficios == {"Fondo de ahorro (2 %)": pytest.approx(19_000)}


def test_sin_fondo_si_no_acepta_o_no_supera_1_anio():
    assert crear(acepta=False).obtener_beneficios() == {}
    assert crear(anios=1, acepta=True).obtener_beneficios() == {}
